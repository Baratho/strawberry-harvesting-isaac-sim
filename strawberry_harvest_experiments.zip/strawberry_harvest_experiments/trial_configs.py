"""Scene-only parameters for the ten strawberry-harvesting experiments.

Keep planning and controller settings in harvest_pipeline.py unchanged between
trials.  This file intentionally contains only scene variations so the ten
results remain comparable.
"""

from copy import deepcopy


DEFAULT_SCENE = {
    "fruit_radius": 0.030,
    "plant_base_position": [0.550, 0.000, 0.060],
    "plant_base_scale": [0.280, 0.280, 0.120],
    "stem_position": [0.550, 0.000, 0.290],
    "stem_scale": [0.025, 0.025, 0.360],
    "leaf_0_scale": [0.170, 0.060, 0.018],
    "leaf_1_scale": [0.160, 0.065, 0.016],
    "neighbor_radius": 0.030,
}


TRIAL_CONFIGS = {
    1: {
        "description": "baseline moderate occlusion",
        "difficulty": "easy",
        "purpose": "Reference success case with a centered target.",
        "fruit_position": [0.550, 0.000, 0.500],
        "leaf_0_position": [0.485, 0.025, 0.545],
        "leaf_1_position": [0.595, -0.020, 0.540],
        "neighbor_position": [0.555, -0.105, 0.490],
    },
    2: {
        "description": "target left and slightly lower",
        "difficulty": "moderate",
        "purpose": "Preserve the validated scene used during development.",
        "fruit_position": [0.520, 0.030, 0.480],
        "leaf_0_position": [0.485, 0.025, 0.525],
        "leaf_1_position": [0.595, -0.020, 0.530],
        "neighbor_position": [0.555, -0.105, 0.490],
    },
    3: {
        "description": "target shifted right",
        "difficulty": "moderate",
        "purpose": "Test lateral workspace variation on the stem side.",
        "fruit_position": [0.545, -0.030, 0.490],
        "leaf_0_position": [0.485, 0.025, 0.535],
        "leaf_1_position": [0.610, -0.020, 0.535],
        "neighbor_position": [0.570, -0.110, 0.485],
    },
    4: {
        "description": "high target with raised canopy",
        "difficulty": "moderate",
        "purpose": "Test a higher target while preserving physical clearance.",
        "fruit_position": [0.530, 0.020, 0.540],
        "leaf_0_position": [0.485, 0.025, 0.585],
        "leaf_1_position": [0.595, -0.020, 0.580],
        "neighbor_position": [0.560, -0.100, 0.535],
    },
    5: {
        "description": "low target near plant base",
        "difficulty": "moderate-hard",
        "purpose": "Test lower-height reachability and base clearance.",
        "fruit_position": [0.530, 0.020, 0.430],
        "leaf_0_position": [0.480, 0.030, 0.480],
        "leaf_1_position": [0.600, -0.020, 0.480],
        "neighbor_position": [0.560, -0.105, 0.440],
    },
    6: {
        "description": "target displaced toward neighboring fruit",
        "difficulty": "hard",
        "purpose": "Test approach selection in reduced neighbor clearance.",
        "fruit_position": [0.530, -0.045, 0.490],
        "leaf_0_position": [0.480, 0.020, 0.535],
        "leaf_1_position": [0.600, -0.030, 0.535],
        "neighbor_position": [0.565, -0.110, 0.490],
    },
    7: {
        "description": "strong single-leaf occlusion",
        "difficulty": "hard",
        "purpose": "Test whether the planner avoids a lowered, wider leaf.",
        "fruit_position": [0.520, 0.030, 0.480],
        "leaf_0_position": [0.485, 0.025, 0.522],
        "leaf_0_scale": [0.180, 0.075, 0.014],
        "leaf_1_position": [0.600, -0.020, 0.535],
        "neighbor_position": [0.560, -0.110, 0.490],
    },
    8: {
        "description": "dual-leaf narrow corridor",
        "difficulty": "very hard",
        "purpose": "Test planning through a narrow two-leaf opening.",
        "fruit_position": [0.535, 0.000, 0.490],
        "leaf_0_position": [0.490, 0.040, 0.530],
        "leaf_0_scale": [0.185, 0.075, 0.016],
        "leaf_1_position": [0.585, -0.040, 0.530],
        "leaf_1_scale": [0.180, 0.075, 0.016],
        "neighbor_position": [0.570, -0.115, 0.490],
    },
    9: {
        "description": "neighbor blocks preferred minus-60-degree approach",
        "difficulty": "very hard",
        "purpose": "Test whether global comparison selects a different angle.",
        "fruit_position": [0.520, 0.030, 0.480],
        "leaf_0_position": [0.485, 0.025, 0.525],
        "leaf_1_position": [0.595, -0.020, 0.530],
        "neighbor_position": [0.480, 0.085, 0.480],
    },
    10: {
        "description": "dense overhead canopy failure challenge",
        "difficulty": "failure challenge",
        "purpose": "Provide a severe occlusion case for failure analysis.",
        "fruit_position": [0.550, 0.000, 0.470],
        "leaf_0_position": [0.550, 0.000, 0.515],
        "leaf_0_scale": [0.280, 0.280, 0.020],
        "leaf_1_position": [0.575, -0.030, 0.510],
        "leaf_1_scale": [0.200, 0.120, 0.016],
        "neighbor_position": [0.505, -0.055, 0.470],
    },
}


def get_trial_config(trial_id):
    """Return one merged, independent configuration dictionary."""
    if trial_id not in TRIAL_CONFIGS:
        valid = ", ".join(str(value) for value in sorted(TRIAL_CONFIGS))
        raise ValueError(f"Unknown trial_id={trial_id}. Valid IDs: {valid}")

    config = deepcopy(DEFAULT_SCENE)
    config.update(deepcopy(TRIAL_CONFIGS[trial_id]))
    return config


def available_trial_ids():
    return sorted(TRIAL_CONFIGS)
